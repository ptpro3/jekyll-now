//
//  ViewController.swift
//  RoboCuller
//
//  Created by Prashant Tatineni on 6/16/19.
//  Copyright © 2019 Prashant Tatineni. All rights reserved.
//

import Cocoa
import Vision

class ViewController: NSViewController {
    
    @IBOutlet weak var selectedLabel: NSTextField!
    @IBOutlet weak var runButton: NSButton!
    var inputImage: NSImage!
    var resultLabel: String!
    var resultConf: Float!
    
    var filesList: [URL] = []
    var isDirectory: ObjCBool = false

    var selectedFolder: URL? {
        didSet {
            if let selectedFolder = selectedFolder {
                filesList = contentsOf(folder: selectedFolder)
                runButton.isEnabled = true
                selectedLabel.stringValue = selectedFolder.path
            } else {
                runButton.isEnabled = false
            }
        }
    }
    
    func contentsOf(folder: URL) -> [URL] {
        let fileManager = FileManager.default
        do {
            let contents = try fileManager.contentsOfDirectory(atPath: folder.path)
            let urls = contents.map { return folder.appendingPathComponent($0) }
            return urls
        } catch {
            return []
        }
    }
    
    lazy var classificationRequest: VNCoreMLRequest = {
        do {
            let model = try VNCoreMLModel(for: BlurClassifier2().model)
            let request = VNCoreMLRequest(model: model, completionHandler: { [weak self] request, error in
                self?.processClassifications(for: request, error: error)
            })
            //request.imageCropAndScaleOption = .scaleFill
            return request
        } catch {
            fatalError("Failed to load Vision ML model: \(error)")
        }
    }()
    
    func processClassifications(for request: VNRequest, error: Error?) {
        guard let results = request.results else {
            print("Unable to classify image.\n\(error!.localizedDescription)")
            return
        }
        let classifications = results as! [VNClassificationObservation]
        let topClassification = classifications.prefix(1)
        for result in topClassification {
            //print(result.confidence)
            self.resultConf = result.confidence
            //print(result.identifier)
            self.resultLabel = result.identifier
        }
    }

    @IBAction func contentFolderClicked(_ sender: Any) {
        guard let window = view.window else { return }

        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false

        panel.beginSheetModal(for: window) { (result) in
            if result.rawValue == NSApplication.ModalResponse.OK.rawValue {
            self.selectedFolder = panel.urls[0]
            }
        }
    }

    @IBAction func runButtonClicked(_ sender: Any) {
        let rejectsFolder = selectedFolder!.appendingPathComponent("Reject")
        let reviewFolder = selectedFolder!.appendingPathComponent("Review")
        //FileManager.default.fileExists(atPath: rejectsFolder.path, isDirectory: &isDirectory)
        // setup rejects folder
//        if !isDirectory.boolValue {
        do{
            try FileManager.default.createDirectory(at: rejectsFolder, withIntermediateDirectories: false, attributes: nil)
        }
        catch let error{
            dump(error)
        }
        do{
            try FileManager.default.createDirectory(at: reviewFolder, withIntermediateDirectories: false, attributes: nil)
        }
        catch let error{
            dump(error)
        }
//        }
        for fileName in filesList {
            // Setup handler and run the classifier
            if fileName.pathExtension != "" {
                let handler = VNImageRequestHandler(url: fileName)
                do {
                    try handler.perform([self.classificationRequest])
                } catch {
                    print("Failed!")
                }
                if self.resultLabel == "Bad" {
                    print("-----")
                    print(fileName.lastPathComponent)
                    print(self.resultConf!)
                    do{
                        if self.resultConf < 0.97 {
                            let destPath = reviewFolder.appendingPathComponent(fileName.lastPathComponent)
                            try FileManager.default.moveItem(at: fileName, to: destPath)
                        } else {
                            let destPath = rejectsFolder.appendingPathComponent(fileName.lastPathComponent)
                            try FileManager.default.moveItem(at: fileName, to: destPath)
                        }
                    }
                    catch let error{
                        dump(error)
                    }
                }
            }
        }
        runButton.isEnabled = false
    }
}
