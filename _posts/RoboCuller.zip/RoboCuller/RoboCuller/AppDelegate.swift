//
//  AppDelegate.swift
//  RoboCuller
//
//  Created by Prashant Tatineni on 6/16/19.
//  Copyright © 2019 Prashant Tatineni. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

